import re
import sys
import os

# ------------------------------
# Global State
# ------------------------------
variables = {}
functions = {}
labels = {}
program_lines = []
current_line = 0

# ------------------------------
# Utilities
# ------------------------------

def strip_inline_comment(line: str) -> str:
    """Remove inline comments (// or #) that occur outside quotes.
    Supports single ('') and double ("") quoted strings. No escape handling.
    """
    in_single = False
    in_double = False
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == '"' and not in_single:
            in_double = not in_double
            i += 1
            continue
        if ch == "'" and not in_double:
            in_single = not in_single
            i += 1
            continue
        if not in_single and not in_double:
            if ch == '/' and i + 1 < len(line) and line[i+1] == '/':
                return line[:i].rstrip()
            if ch == '#':
                return line[:i].rstrip()
        i += 1
    return line.rstrip()

def substitute_variables(text):
    """Replace <`VAR`> with its value."""
    matches = re.findall(r"<`(.*?)`>", text)
    for var in matches:
        value = variables.get(var, f"<UNDEFINED:{var}>")
        text = text.replace(f"<`{var}`>", value)
    return text

def parse_value(value):
    """Handles quoted strings or variable references."""
    value = value.strip()
    if value.startswith('"') and value.endswith('"'):
        return value.strip('"')
    return variables.get(value, value)

def send_to_hardware(text):
    """Simulate writing to hardware by appending to a hardware_output.log file next to the script.
    This keeps real hardware access safe while giving a place to inspect DIRECT output.
    """
    try:
        log_path = os.path.join(os.path.dirname(__file__), "hardware_output.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(text + "\n")
    except Exception as e:
        print(f"[ERROR] Failed to write to hardware log: {e}")


def display_to_shell(text):
    """Send text to the interactive shell (stdout)."""
    print(text)

# ------------------------------
# Instruction Handlers
# ------------------------------
def handle_set(line):
    # Example: Set[USER]= "Logan"
    match = re.match(r"Set\[(.*?)\]\s*=\s*(.*)", line)
    if not match:
        print(f"[ERROR] Invalid Set syntax: {line}")
        return

    var_name = match.group(1)
    raw_value = match.group(2).strip()

    # Support DisplayText(TAG)=... where TAG can be DIRECT or SHELL (case-insensitive)
    dt_match = re.match(r"DisplayText\((.*?)\)\s*=\s*([\"'])(.*)\2\s*$", raw_value)
    if dt_match:
        tag = dt_match.group(1).strip().upper()
        value = dt_match.group(3).strip()
        value = substitute_variables(value)
        # Route according to tag
        if tag == "DIRECT":
            # do not print to shell; write to simulated hardware
            send_to_hardware(value)
            # store the raw value in variable as well, in case code expects it
            variables[var_name] = value
        elif tag == "SHELL":
            display_to_shell(value)
            variables[var_name] = value
        else:
            # Unknown tag: default to shell and warn
            print(f"[WARN] Unknown DisplayText tag '{tag}', defaulting to SHELL")
            display_to_shell(value)
            variables[var_name] = value
        return

    # Fallback: normal value or variable reference
    if raw_value.startswith('"') and raw_value.endswith('"'):
        variables[var_name] = substitute_variables(raw_value.strip('"'))
    else:
        variables[var_name] = parse_value(raw_value)


def handle_display(line):
    # line format: DisplayText(TAG)=<content>
    match = re.match(r"DisplayText\((.*?)\)\s*=\s*([\"'])(.*)\2\s*$", line)
    if not match:
        print(f"[ERROR] Invalid DisplayText syntax (must be quoted): {line}")
        return

    tag = match.group(1).strip().upper()
    content = match.group(3).strip()
    content = substitute_variables(content)

    if tag == "SHELL":
        display_to_shell(content)
    elif tag == "DIRECT":
        # Do not print to shell; write to simulated hardware
        send_to_hardware(content)
    else:
        print(f"[WARN] Unknown DisplayText tag '{tag}', defaulting to SHELL")
        display_to_shell(content)

def handle_input():
    user_input = input("> ").strip()
    variables["INPUT"] = user_input
    print(f"[DEBUG] INPUT received: '{user_input}'")  # You can remove this later

def handle_if(line):
    try:
        # Prefer quoted RHS: If[VAR]="value" or If[VAR]='value'
        match = re.match(r"If\[(.*?)\]\s*=\s*[\"'](.*)[\"']\s*$", line)
        if match:
            left = match.group(1).strip()
            right = match.group(2)
        else:
            # Backwards-compatible: accept unquoted RHS like If[VAR]=value (warn)
            match2 = re.match(r"If\[(.*?)\]\s*=\s*(\S+)\s*$", line)
            if not match2:
                print(f"[ERROR] Invalid If condition: '{line}'. Expected format: If[VAR]=\"value\"")
                return False
            left = match2.group(1).strip()
            right = match2.group(2)
            print(f"[WARN] If RHS not quoted: treating '{right}' as string")

        left_val = variables.get(left, "").strip()
        return left_val == right

    except Exception as e:
        print(f"[ERROR] Failed to parse If condition: {e}")
        return False


def handle_loop(start_index):
    global current_line
    loop_lines = []
    i = start_index + 1
    while i < len(program_lines) and not program_lines[i].strip().startswith("EndLoop"):
        loop_lines.append(program_lines[i])
        i += 1
    while True:
        for line in loop_lines:
            execute_line(line)
    current_line = i  # Will never reach this due to infinite loop

def handle_goto(label):
    global current_line
    if label in labels:
        current_line = labels[label]
    else:
        print(f"[ERROR] Label '{label}' not found.")
        sys.exit(1)

def handle_call(func_name):
    if func_name not in functions:
        print(f"[ERROR] Function '{func_name}' not found.")
        return
    for line in functions[func_name]:
        execute_line(line)

# ------------------------------
# Interpreter
# ------------------------------
def execute_line(line):
    global current_line

    line = line.strip()
    # Remove inline comments outside quotes first
    line = strip_inline_comment(line)
    if not line or line.startswith("//"):
        return  

    # Structural-only keywords: tolerate optional spaces in the bit declaration
    if line.replace(" ", "") in ("[16BIT]", "startprogram", "endprogram", "startsection", "endsection"):
        return

    if line.startswith("Set["):
        handle_set(line)

    elif line.startswith("DisplayText(DIRECT)=") or line.startswith("DisplayText(SHELL)="):
        handle_display(line)

    elif line.startswith("TrackInput[KEYBOARD]"):
        handle_input()

    elif line.startswith("If[") and "=" in line:
        if not handle_if(line):
            current_line += 1  # Skip next line if condition fails

    elif line.startswith("Loop[FOREVER]"):
        handle_loop(current_line)

    elif line.startswith("Goto["):
        label = line.split("Goto[", 1)[1].split("]", 1)[0]
        handle_goto(label)

    elif line.startswith("CallFunction["):
        func = line.split("CallFunction[", 1)[1].split("]", 1)[0]
        handle_call(func)

    elif line.startswith("StartFunction[") or line == "EndFunction":
        return  # Already handled in preload

    # Accept new Label[...] syntax; also accept old Label:NAME for compatibility
    elif line.startswith("Label[") and "]" in line:
        return  # Already stored
    elif line.startswith("Label:"):
        # backward compatibility: warn and ignore at runtime
        print("[WARN] Deprecated label syntax 'Label:NAME' used; prefer 'Label[NAME]'")
        return  # Already stored

    else:
        print(f"[ERROR] Unknown command: {line}")

# ------------------------------
# Program Loader (First Pass)
# ------------------------------
def load_program(file_path):
    global program_lines, labels, functions

    with open(file_path, "r") as f:
        raw_lines = f.readlines()

    in_function = False
    current_func = ""

    # We'll build a filtered program_lines that excludes function bodies so they are
    # not executed during the main run. Labels must be indexed against the filtered list.
    program_lines = []
    labels = {}
    functions = {}

    for line in raw_lines:
        stripped = line.strip()
        # Remove inline comments outside quotes first
        stripped = strip_inline_comment(stripped)
        # Skip full-line or empty lines after stripping
        if not stripped or stripped.startswith("//"):
            continue

        if stripped.startswith("StartFunction["):
            in_function = True
            current_func = stripped.split("StartFunction[", 1)[1].split("]", 1)[0]
            functions[current_func] = []
            continue

        if stripped == "EndFunction":
            in_function = False
            current_func = ""
            continue

        if in_function:
            # collect function body lines (already stripped)
            if stripped and not stripped.startswith("//"):
                functions[current_func].append(stripped)
            continue

        # Not inside a function: treat as part of the main program
        # New label syntax: Label[NAME]
        if stripped.startswith("Label[") and "]" in stripped:
            label_name = stripped.split("Label[", 1)[1].split("]", 1)[0].strip()
            labels[label_name] = len(program_lines)
        elif stripped.startswith("Label:"):
            # Backwards compatibility: accept old form but warn
            label_name = stripped[6:].strip()
            print(f"[WARN] Deprecated label syntax 'Label:NAME' used for '{label_name}'; prefer 'Label[{label_name}]'")
            labels[label_name] = len(program_lines)

        program_lines.append(stripped)

# ------------------------------
# Runner
# ------------------------------
def run_program():
    global current_line
    current_line = 0
    while current_line < len(program_lines):
        line = program_lines[current_line].strip()
        execute_line(line)
        current_line += 1

# ------------------------------
# Compiler
# ------------------------------
BOOT_SECTOR_SIZE = 512
BOOT_SIGNATURE = b"\x55\xAA"

# Instruction templates (x86 real-mode)
# mov ah, imm8  -> B4 imm8
# mov al, imm8  -> B0 imm8
# int 0x10      -> CD 10
# jmp short -2  -> EB FE  (infinite loop)

MOV_AH = b"\xB4"  # followed by imm8
MOV_AL = b"\xB0"  # followed by imm8
INT_10 = b"\xCD\x10"
JMP_LOOP = b"\xEB\xFE"


def extract_top_level_display_text(lines):
    """Return list of strings to print (in order) found as top-level DisplayText(DIRECT|SHELL)="quoted".
    Enforces quoting; raises on unquoted occurrences to align with interpreter.
    """
    out = []
    in_function = False
    for raw in lines:
        line = strip_inline_comment(raw.strip())
        if not line or line.startswith("//"):
            continue
        # track function blocks and skip their contents
        if line.startswith("StartFunction["):
            in_function = True
            continue
        if line == "EndFunction":
            in_function = False
            continue
        if in_function:
            continue
        # match DisplayText(DIRECT|SHELL)="..." (require quotes)
        m = re.match(r"DisplayText\(\s*(DIRECT|SHELL)\s*\)\s*=\s*([\"'])(.*)\2\s*$", line, flags=re.IGNORECASE)
        if m:
            val = m.group(3)
            out.append(val)
        else:
            # If the line starts like a DisplayText but is not quoted, error out early
            if re.match(r"DisplayText\(\s*(DIRECT|SHELL)\s*\)\s*=\s*\S", line, flags=re.IGNORECASE):
                raise ValueError(f"DisplayText(DIRECT|SHELL) must be quoted: {line}")
    return out


def parse_program_for_compile(lines):
    """Parse .long program into main lines and function bodies (like longi.py)."""
    program_lines = []
    functions = {}
    in_function = False
    current_func = ""

    for raw in lines:
        stripped = strip_inline_comment(raw.strip())
        if not stripped or stripped.startswith("//"):
            continue

        if stripped.startswith("StartFunction["):
            in_function = True
            current_func = stripped.split("StartFunction[", 1)[1].split("]", 1)[0]
            functions[current_func] = []
            continue

        if stripped == "EndFunction":
            in_function = False
            current_func = ""
            continue

        if in_function:
            functions[current_func].append(stripped)
            continue

        program_lines.append(stripped)

    return program_lines, functions


def split_display_segments(text):
    """Split DisplayText content into literal and variable segments."""
    segments = []
    last = 0
    for m in re.finditer(r"<`(.*?)`>", text):
        if m.start() > last:
            segments.append(("text", text[last:m.start()]))
        segments.append(("var", m.group(1)))
        last = m.end()
    if last < len(text):
        segments.append(("text", text[last:]))
    return segments


def compile_lines_to_instrs(lines, var_ids, label_prefix):
    """Compile program lines to instruction specs grouped by line."""
    line_instrs = []
    label_defs = {}  # label_name -> line index
    loop_stack = []
    pending_loop_label = None
    loop_counter = 0

    for idx, line in enumerate(lines):
        instrs = []
        stripped = line.strip()

        if stripped.replace(" ", "") in ("[16BIT]", "startprogram", "endprogram", "startsection", "endsection"):
            line_instrs.append(instrs)
            continue

        if stripped.startswith("Label[") and "]" in stripped:
            label_name = stripped.split("Label[", 1)[1].split("]", 1)[0].strip()
            label_defs[label_name] = idx
            line_instrs.append(instrs)
            continue
        if stripped.startswith("Label:"):
            label_name = stripped[6:].strip()
            label_defs[label_name] = idx
            line_instrs.append(instrs)
            continue

        if stripped.startswith("StartFunction[") or stripped == "EndFunction":
            line_instrs.append(instrs)
            continue

        if stripped.startswith("Loop[FOREVER]"):
            loop_label = f"{label_prefix}_loop_{loop_counter}"
            loop_counter += 1
            loop_stack.append(loop_label)
            pending_loop_label = loop_label
            line_instrs.append(instrs)
            continue

        if stripped.startswith("EndLoop"):
            if not loop_stack:
                print("[WARN] EndLoop without matching Loop[FOREVER]")
                line_instrs.append(instrs)
                continue
            loop_label = loop_stack.pop()
            if pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            instrs.append({"op": "GOTO", "label": loop_label})
            line_instrs.append(instrs)
            continue

        if stripped.startswith("DisplayText("):
            m = re.match(r"DisplayText\(\s*(DIRECT|SHELL)\s*\)\s*=\s*([\"'])(.*)\2\s*$", stripped, re.IGNORECASE)
            if not m:
                print(f"[ERROR] Invalid DisplayText syntax (must be quoted): {line}")
                line_instrs.append(instrs)
                continue
            content = m.group(3)
            for kind, value in split_display_segments(content):
                if kind == "text" and value:
                    instrs.append({"op": "PRINT_STR", "str": value})
                elif kind == "var":
                    var_id = var_ids.get(value)
                    if var_id is None:
                        var_id = len(var_ids)
                        var_ids[value] = var_id
                    instrs.append({"op": "PRINT_VAR", "var_id": var_id})
            # Match longi behavior: each DisplayText ends with a newline
            instrs.append({"op": "PRINT_NL"})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        if stripped.startswith("Set["):
            m = re.match(r"Set\[(.*?)\]\s*=\s*(.*)", stripped)
            if not m:
                print(f"[ERROR] Invalid Set syntax: {line}")
                line_instrs.append(instrs)
                continue
            var_name = m.group(1).strip()
            raw_value = m.group(2).strip()
            if var_name not in var_ids:
                var_ids[var_name] = len(var_ids)
            var_id = var_ids[var_name]

            dt_match = re.match(r"DisplayText\((.*?)\)\s*=\s*([\"'])(.*)\2\s*$", raw_value)
            if dt_match:
                value = dt_match.group(3).strip()
                # Print then set variable
                for kind, v in split_display_segments(value):
                    if kind == "text" and v:
                        instrs.append({"op": "PRINT_STR", "str": v})
                    elif kind == "var":
                        vid = var_ids.get(v)
                        if vid is None:
                            vid = len(var_ids)
                            var_ids[v] = vid
                        instrs.append({"op": "PRINT_VAR", "var_id": vid})
                instrs.append({"op": "SET_STR", "var_id": var_id, "str": value})
                if instrs and pending_loop_label:
                    label_defs[pending_loop_label] = idx
                    pending_loop_label = None
                line_instrs.append(instrs)
                continue

            if raw_value.startswith(("\"", "'")) and raw_value.endswith(("\"", "'")):
                literal = raw_value[1:-1]
                instrs.append({"op": "SET_STR", "var_id": var_id, "str": literal})
                if instrs and pending_loop_label:
                    label_defs[pending_loop_label] = idx
                    pending_loop_label = None
                line_instrs.append(instrs)
                continue

            # variable reference
            ref_name = raw_value
            if ref_name not in var_ids:
                var_ids[ref_name] = len(var_ids)
            instrs.append({"op": "SET_VAR", "dst": var_id, "src": var_ids[ref_name]})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        if stripped.startswith("TrackInput[KEYBOARD]"):
            if "INPUT" not in var_ids:
                var_ids["INPUT"] = len(var_ids)
            instrs.append({"op": "INPUT", "var_id": var_ids["INPUT"]})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        if stripped.startswith("If[") and "=" in stripped:
            m = re.match(r"If\[(.*?)\]\s*=\s*[\"'](.*)[\"']\s*$", stripped)
            if m:
                left = m.group(1).strip()
                right = m.group(2)
            else:
                m2 = re.match(r"If\[(.*?)\]\s*=\s*(\S+)\s*$", stripped)
                if not m2:
                    print(f"[ERROR] Invalid If condition: '{line}'. Expected format: If[VAR]=\"value\"")
                    line_instrs.append(instrs)
                    continue
                left = m2.group(1).strip()
                right = m2.group(2)
                print(f"[WARN] If RHS not quoted: treating '{right}' as string")

            if left not in var_ids:
                var_ids[left] = len(var_ids)
            instrs.append({"op": "IF_EQ", "var_id": var_ids[left], "str": right, "false_target": None})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        if stripped.startswith("Goto["):
            label = stripped.split("Goto[", 1)[1].split("]", 1)[0].strip()
            instrs.append({"op": "GOTO", "label": label})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        if stripped.startswith("CallFunction["):
            func = stripped.split("CallFunction[", 1)[1].split("]", 1)[0].strip()
            instrs.append({"op": "CALL", "label": f"FUNC_{func}"})
            if instrs and pending_loop_label:
                label_defs[pending_loop_label] = idx
                pending_loop_label = None
            line_instrs.append(instrs)
            continue

        print(f"[WARN] Unrecognized command skipped in compile: {line}")
        if instrs and pending_loop_label:
            label_defs[pending_loop_label] = idx
            pending_loop_label = None
        line_instrs.append(instrs)

    return line_instrs, label_defs, loop_stack, pending_loop_label


def generate_stage2_asm(program_lines, functions, asm_path):
    """Generate stage-2 assembly with a tiny bytecode VM to run longi-like commands."""
    var_ids = {}
    # Pre-seed INPUT to keep id stable if referenced later
    var_ids["INPUT"] = 0

    main_line_instrs, main_labels, _, pending_loop_label = compile_lines_to_instrs(
        program_lines, var_ids, "MAIN"
    )

    if pending_loop_label:
        # Ensure loop label exists even if loop body is empty
        main_labels[pending_loop_label] = max(0, len(main_line_instrs) - 1)

    # Compile functions
    func_line_instrs_map = {}
    func_labels_map = {}
    for fname, flines in functions.items():
        fl_instrs, flabels, _, pending = compile_lines_to_instrs(
            flines, var_ids, f"FUNC_{fname}"
        )
        if pending:
            flabels[pending] = max(0, len(fl_instrs) - 1)
        func_line_instrs_map[fname] = fl_instrs
        func_labels_map[fname] = flabels

    # Flatten line-instruction lists and map line indices to instruction indices
    def flatten(line_instrs):
        instrs = []
        line_first = [None] * len(line_instrs)
        line_last = [None] * len(line_instrs)
        for i, lst in enumerate(line_instrs):
            if not lst:
                continue
            line_first[i] = len(instrs)
            instrs.extend(lst)
            line_last[i] = len(instrs) - 1
        return instrs, line_first, line_last

    main_instrs, main_first, main_last = flatten(main_line_instrs)

    # Compute next-exec index per line for IF skip behavior
    def compute_next_exec(line_first, line_last):
        next_exec = None
        next_after = [None] * len(line_first)
        for i in range(len(line_first) - 1, -1, -1):
            next_after[i] = next_exec
            if line_first[i] is not None:
                next_exec = line_first[i]
        return next_after

    main_next_after = compute_next_exec(main_first, main_last)

    # Patch IF false targets (skip next line's instructions)
    for i, lst in enumerate(main_line_instrs):
        for instr in lst:
            if instr.get("op") == "IF_EQ" and instr.get("false_target") is None:
                if i + 1 < len(main_next_after):
                    instr["false_target"] = main_next_after[i + 1]
                else:
                    instr["false_target"] = None

    # Flatten function instructions and build global instruction list
    func_instrs = []
    func_entry_indices = {}
    func_end_indices = {}
    func_next_after = {}

    for fname, flines in func_line_instrs_map.items():
        instrs, first, last = flatten(flines)
        next_after = compute_next_exec(first, last)
        # Patch IF in functions
        for i, lst in enumerate(flines):
            for instr in lst:
                if instr.get("op") == "IF_EQ" and instr.get("false_target") is None:
                    if i + 1 < len(next_after):
                        instr["false_target"] = next_after[i + 1]
                    else:
                        instr["false_target"] = None
        func_entry_indices[fname] = len(main_instrs) + len(func_instrs)
        func_instrs.extend(instrs)
        func_end_indices[fname] = len(main_instrs) + len(func_instrs)

    # Append RET at end of each function if there are any instructions
    func_ret_indices = {}
    if func_instrs:
        # Insert RET after each function block by tracking sizes
        new_func_instrs = []
        offset = 0
        for fname, flines in func_line_instrs_map.items():
            instrs, _, _ = flatten(flines)
            func_entry_indices[fname] = len(main_instrs) + offset
            new_func_instrs.extend(instrs)
            new_func_instrs.append({"op": "RET"})
            offset = len(new_func_instrs)
            func_ret_indices[fname] = len(main_instrs) + offset - 1
        func_instrs = new_func_instrs

    all_instrs = main_instrs + func_instrs

    # Build label indices for GOTO/CALL/labels
    label_to_index = {}

    def apply_labels_from_lines(line_instrs, labels, base_index, max_index=None):
        # label definitions are line-based; point to first instruction on that line
        for name, line_idx in labels.items():
            line_instr_list = line_instrs[line_idx] if line_idx < len(line_instrs) else []
            if line_instr_list:
                # Find the instruction index by summing lengths
                idx = base_index
                for i in range(line_idx):
                    idx += len(line_instrs[i])
                if max_index is not None and idx >= max_index:
                    label_to_index[name] = None
                else:
                    label_to_index[name] = idx
            else:
                # label on empty line -> point to next instruction
                idx = base_index
                for i in range(line_idx + 1):
                    idx += len(line_instrs[i])
                if max_index is not None and idx >= max_index:
                    label_to_index[name] = None
                else:
                    label_to_index[name] = idx

    apply_labels_from_lines(main_line_instrs, main_labels, 0, max_index=len(main_instrs))
    for fname, flines in func_line_instrs_map.items():
        flabels = func_labels_map.get(fname, {})
        base = func_entry_indices.get(fname, len(main_instrs))
        apply_labels_from_lines(flines, flabels, base)
        label_to_index[f"FUNC_{fname}"] = base

    def label_to_addr(label):
        idx = label_to_index.get(label)
        if idx is None or idx >= len(instr_labels):
            return "program_end"
        return instr_labels[idx]

    # Collect unique strings
    strings = []
    string_labels = {}

    def get_string_label(value):
        if value not in string_labels:
            string_labels[value] = f"str_{len(strings)}"
            strings.append(value)
        return string_labels[value]

    # Assign instruction labels
    instr_labels = [f"L{i}" for i in range(len(all_instrs))]

    # Emit assembly
    asm = []
    asm += [
        "bits 16",
        "org 0x8000",
        "",
        "start2:",
        "    cli",
        "    xor ax, ax",
        "    mov ds, ax",
        "    mov es, ax",
        "    mov ss, ax",
        "    mov sp, 0x7C00",
        "    sti",
        "    mov si, program",
        "    call vm_run",
        "    cli",
        "    hlt",
        "",
        "; -------------- VM --------------",
        "vm_run:",
        "    .loop:",
        "    lodsb",
        "    cmp al, 0x01",
        "    je .op_print_str",
        "    cmp al, 0x02",
        "    je .op_print_var",
        "    cmp al, 0x03",
        "    je .op_set_str",
        "    cmp al, 0x04",
        "    je .op_set_var",
        "    cmp al, 0x05",
        "    je .op_input",
        "    cmp al, 0x06",
        "    je .op_if_eq",
        "    cmp al, 0x07",
        "    je .op_goto",
        "    cmp al, 0x08",
        "    je .op_call",
        "    cmp al, 0x09",
        "    je .op_ret",
        "    cmp al, 0x0A",
        "    je .op_end",
        "    cmp al, 0x0B",
        "    je .op_nl",
        "    jmp .loop",
        "",
        "    .op_print_str:",
        "    lodsw",
        "    push si",
        "    mov si, ax",
        "    call print_string",
        "    pop si",
        "    jmp .loop",
        "",
        "    .op_print_var:",
        "    lodsb",
        "    xor bx, bx",
        "    mov bl, al",
        "    shl bx, 1",
        "    mov di, [var_table + bx]",
        "    push si",
        "    mov si, di",
        "    call print_string",
        "    pop si",
        "    jmp .loop",
        "",
        "    .op_set_str:",
        "    lodsb",
        "    mov dl, al",
        "    lodsw",
        "    mov bp, si",
        "    mov si, ax",
        "    xor bx, bx",
        "    mov bl, dl",
        "    shl bx, 1",
        "    mov di, [var_table + bx]",
        "    call copy_string",
        "    mov si, bp",
        "    jmp .loop",
        "",
        "    .op_set_var:",
        "    lodsb",
        "    mov dl, al",
        "    lodsb",
        "    mov dh, al",
        "    mov bp, si",
        "    xor bx, bx",
        "    mov bl, dl",
        "    shl bx, 1",
        "    mov di, [var_table + bx]",
        "    xor bx, bx",
        "    mov bl, dh",
        "    shl bx, 1",
        "    mov si, [var_table + bx]",
        "    call copy_string",
        "    mov si, bp",
        "    jmp .loop",
        "",
        "    .op_input:",
        "    lodsb",
        "    mov dl, al",
        "    mov bp, si",
        "    call read_line",
        "    xor bx, bx",
        "    mov bl, dl",
        "    shl bx, 1",
        "    mov di, [var_table + bx]",
        "    mov si, inbuf",
        "    call copy_string",
        "    mov si, bp",
        "    jmp .loop",
        "",
        "    .op_if_eq:",
        "    lodsb",
        "    mov dl, al",
        "    lodsw",
        "    mov di, ax",
        "    lodsw",
        "    mov cx, ax",
        "    mov bp, si",
        "    xor ax, ax",
        "    mov al, dl",
        "    shl ax, 1",
        "    mov bx, ax",
        "    mov si, [var_table + bx]",
        "    call strcmp",
        "    cmp al, 1",
        "    je .if_true",
        "    mov si, cx",
        "    jmp .loop",
        "    .if_true:",
        "    mov si, bp",
        "    jmp .loop",
        "",
        "    .op_goto:",
        "    lodsw",
        "    mov si, ax",
        "    jmp .loop",
        "",
        "    .op_call:",
        "    lodsw",
        "    mov bp, ax",
        "    push si",
        "    call push_ret",
        "    pop si",
        "    mov si, bp",
        "    jmp .loop",
        "",
        "    .op_ret:",
        "    call pop_ret",
        "    mov si, bx",
        "    jmp .loop",
        "",
        "    .op_end:",
        "    cli",
        "    hlt",
        "",
        "    .op_nl:",
        "    mov al, 0x0D",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    mov al, 0x0A",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    jmp .loop",
        "",
        "; -------------- Helpers --------------",
        "print_string:",
        "    .ps_loop:",
        "    lodsb",
        "    cmp al, 0",
        "    je .ps_ret",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    jmp .ps_loop",
        "    .ps_ret:",
        "    ret",
        "",
        "read_line:",
        "    mov di, inbuf",
        "    mov bx, di",
        "    .rl_loop:",
        "    mov ah, 0x00",
        "    int 0x16",
        "    cmp al, 0x0D",
        "    je .rl_done",
        "    cmp al, 0x08",
        "    je .rl_backspace",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    stosb",
        "    jmp .rl_loop",
        "    .rl_backspace:",
        "    cmp di, bx",
        "    je .rl_loop",
        "    dec di",
        "    mov al, 0x08",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    mov al, 0x20",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    mov al, 0x08",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    jmp .rl_loop",
        "    .rl_done:",
        "    mov byte [di], 0",
        "    mov al, 0x0D",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    mov al, 0x0A",
        "    mov ah, 0x0E",
        "    int 0x10",
        "    ret",
        "",
        "copy_string:",
        "    mov cx, 63",
        "    .cs_loop:",
        "    lodsb",
        "    mov [di], al",
        "    inc di",
        "    cmp al, 0",
        "    je .cs_done",
        "    loop .cs_loop",
        "    mov byte [di], 0",
        "    .cs_done:",
        "    ret",
        "",
        "strcmp:",
        "    .sc_loop:",
        "    mov al, [si]",
        "    mov bl, [di]",
        "    cmp al, bl",
        "    jne .sc_ne",
        "    cmp al, 0",
        "    je .sc_eq",
        "    inc si",
        "    inc di",
        "    jmp .sc_loop",
        "    .sc_ne:",
        "    mov al, 0",
        "    ret",
        "    .sc_eq:",
        "    mov al, 1",
        "    ret",
        "",
        "push_ret:",
        "    mov al, [call_sp]",
        "    cmp al, 16",
        "    jae .pr_over",
        "    mov bl, al",
        "    shl bx, 1",
        "    mov [call_stack + bx], si",
        "    inc al",
        "    mov [call_sp], al",
        "    ret",
        "    .pr_over:",
        "    ret",
        "",
        "pop_ret:",
        "    mov al, [call_sp]",
        "    cmp al, 0",
        "    je .pr_under",
        "    dec al",
        "    mov [call_sp], al",
        "    mov bl, al",
        "    shl bx, 1",
        "    mov bx, [call_stack + bx]",
        "    ret",
        "    .pr_under:",
        "    mov bx, program_end",
        "    ret",
        "",
        "; -------------- Bytecode --------------",
        "program:",
    ]

    for i, instr in enumerate(all_instrs):
        asm.append(f"{instr_labels[i]}:")
        op = instr["op"]
        if op == "PRINT_STR":
            asm.append("    db 0x01")
            asm.append(f"    dw {get_string_label(instr['str'])}")
        elif op == "PRINT_VAR":
            asm.append("    db 0x02")
            asm.append(f"    db {instr['var_id']}")
        elif op == "SET_STR":
            asm.append("    db 0x03")
            asm.append(f"    db {instr['var_id']}")
            asm.append(f"    dw {get_string_label(instr['str'])}")
        elif op == "SET_VAR":
            asm.append("    db 0x04")
            asm.append(f"    db {instr['dst']}")
            asm.append(f"    db {instr['src']}")
        elif op == "INPUT":
            asm.append("    db 0x05")
            asm.append(f"    db {instr['var_id']}")
        elif op == "IF_EQ":
            asm.append("    db 0x06")
            asm.append(f"    db {instr['var_id']}")
            asm.append(f"    dw {get_string_label(instr['str'])}")
            false_idx = instr.get("false_target")
            if false_idx is None or false_idx >= len(instr_labels):
                asm.append("    dw program_end")
            else:
                asm.append(f"    dw {instr_labels[false_idx]}")
        elif op == "GOTO":
            asm.append("    db 0x07")
            asm.append(f"    dw {label_to_addr(instr['label'])}")
        elif op == "CALL":
            asm.append("    db 0x08")
            asm.append(f"    dw {label_to_addr(instr['label'])}")
        elif op == "RET":
            asm.append("    db 0x09")
        elif op == "PRINT_NL":
            asm.append("    db 0x0B")
        else:
            asm.append("    db 0x0A")

    asm += [
        "program_end:",
        "    db 0x0A",
        "",
        "; -------------- Data --------------",
        "inbuf: times 80 db 0",
        "call_sp db 0",
        "call_stack: times 16 dw 0",
        "",
    ]

    # Var buffers and table
    var_count = max(1, len(var_ids))
    for i in range(var_count):
        asm.append(f"var_{i}: times 64 db 0")
    asm.append("var_table:")
    for i in range(var_count):
        asm.append(f"    dw var_{i}")

    # Strings
    for s in strings:
        safe = s.replace('"', '\\"')
        asm.append(f"{get_string_label(s)} db \"{safe}\", 0")

    with open(asm_path, "w", encoding="utf-8") as f:
        f.write("\n".join(asm))


def generate_stage1_asm(stage2_sectors, asm_path):
    asm_lines = [
        "bits 16",
        "org 0x7C00",
        "",
        "start:",
        "    xor ax, ax",
        "    mov ds, ax",
        "    mov es, ax",
        "    mov ss, ax",
        "    mov sp, 0x7C00",
        "    mov [boot_drive], dl",
        "",
        "    ; load stage2 (starting at sector 2) to 0x0000:0x8000",
        "    mov bx, 0x8000",
        "    mov ah, 0x02",
        f"    mov al, {stage2_sectors}",
        "    mov ch, 0",
        "    mov cl, 2",
        "    mov dh, 0",
        "    mov dl, [boot_drive]",
        "    int 0x13",
        "    jc disk_error",
        "",
        "    jmp 0x0000:0x8000",
        "",
        "disk_error:",
        "    mov si, errormsg",
        "    call print_str",
        "    cli",
        "    hlt",
        "",
        "print_str:",
        "    mov ah, 0x0E",
        "    .next:",
        "    lodsb",
        "    cmp al, 0",
        "    je .done",
        "    int 0x10",
        "    jmp .next",
        "    .done:",
        "    ret",
        "",
        "boot_drive db 0",
        "errormsg db '[ERROR] Disk read failed!', 0",
        "",
        "times 510 - ($ - $$) db 0",
        "dw 0xAA55",
    ]

    with open(asm_path, "w", encoding="utf-8") as f:
        f.write("\n".join(asm_lines))


def compile_to_boot_sector(source_file, output_file):
    if not os.path.isfile(source_file):
        print(f"Source file not found: {source_file}")
        sys.exit(1)

    with open(source_file, "r", encoding="utf-8") as f:
        lines = f.readlines()

    program_lines, functions = parse_program_for_compile(lines)

    base = os.path.splitext(output_file)[0]
    stage2_asm = base + "_stage2.asm"
    stage2_bin = base + "_stage2.bin"
    stage1_asm = base + "_stage1.asm"
    stage1_bin = base + "_stage1.bin"

    try:
        generate_stage2_asm(program_lines, functions, stage2_asm)
    except Exception as e:
        print(f"[ERROR] Failed to generate asm: {e}")
        sys.exit(1)

    # Assemble with nasm if available
    try:
        import subprocess
        res2 = subprocess.run(["nasm", "-f", "bin", stage2_asm, "-o", stage2_bin], check=False)
        if res2.returncode != 0:
            print("[ERROR] nasm failed to assemble stage2. Ensure nasm is installed and on PATH.")
            sys.exit(1)
    except FileNotFoundError:
        print("[ERROR] nasm not found. Install nasm or assemble the generated .asm manually.")
        sys.exit(1)

    stage2_size = os.path.getsize(stage2_bin)
    stage2_sectors = (stage2_size + 511) // 512

    try:
        generate_stage1_asm(stage2_sectors, stage1_asm)
        res1 = subprocess.run(["nasm", "-f", "bin", stage1_asm, "-o", stage1_bin], check=False)
        if res1.returncode != 0:
            print("[ERROR] nasm failed to assemble stage1 bootloader.")
            sys.exit(1)
    except FileNotFoundError:
        print("[ERROR] nasm not found. Install nasm or assemble the generated .asm manually.")
        sys.exit(1)

    # Build boot image: stage1 (512 bytes) + stage2 (padded to sectors)
    with open(stage1_bin, "rb") as f:
        boot_sector = f.read()
    if len(boot_sector) != 512:
        print("[ERROR] stage1 boot sector is not 512 bytes.")
        sys.exit(1)

    with open(stage2_bin, "rb") as f:
        stage2_data = f.read()
    pad_len = (stage2_sectors * 512) - len(stage2_data)
    if pad_len < 0:
        pad_len = 0
    stage2_data += b"\x00" * pad_len

    with open(output_file, "wb") as f:
        f.write(boot_sector)
        f.write(stage2_data)

    # Report success
    size = os.path.getsize(output_file)
    print(f"Wrote bootable image: {output_file} ({size} bytes)")
    print("You can boot it in QEMU: qemu-system-i386 -drive format=raw,file=%s" % output_file)

# ------------------------------
# Entry Point
# ------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python longc2.py <program.long> [output.img]")
        sys.exit(1)

    if len(sys.argv) == 3 and sys.argv[2].endswith(".bin"):
        compile_to_boot_sector(sys.argv[1], sys.argv[2])
    elif len(sys.argv) == 2 and sys.argv[1].endswith(".long"):
        compile_to_boot_sector(sys.argv[1], "boot.bin")
    else:
        load_program(sys.argv[1])
        run_program()
